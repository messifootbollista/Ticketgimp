# ticketgimp

Create TicketMaster-compatible rotating barcodes from encoded ticket secrets.

[See my full blog post](https://conduition.io/coding/ticketmaster/) for explanation and context.
